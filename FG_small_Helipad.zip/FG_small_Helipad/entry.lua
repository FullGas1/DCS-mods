local function add_structure(f)
	if(f) then
		f.shape_table_data = 
		{
			{
				file  	    = f.ShapeName,
				life		= f.Life,
				username    = f.Name,
				desrt       = f.ShapeNameDestr or "self",
			    classname 	= f.classname   or "lLandVehicle",
				positioning = f.positioning or "BYNORMAL"	--available: {"BYNORMAL", "ONLYHEIGTH", "BY_XZ", "ADD_HEIGTH"}
			}
		}
		if f.ShapeNameDestr then
			f.shape_table_data[#f.shape_table_data + 1] = 
			{
				name  = f.ShapeName,
				file  = f.ShapeNameDestr,	
			}
		end
		
		
		f.mapclasskey = "P0091000076";
		f.attribute = {wsType_Static, wsType_Standing} -- if 'attribute' == nil then insertion will be aborted
		
		add_surface_unit(f)
		GT = nil;
	else
		error("Can't add structure")
	end;
end
-----------------------------------------------------------------------------------
declare_plugin("FG_small_Helipad",
{
installed 	 	  = true,
state		 	  = "installed",
developerName	  = "FullGas",
version		 	  = __DCS_VERSION__,
description       = "Small metal helipad for ground placement."
category          = "Helipad"	 -- non DCS category only for sorting mods
})
mount_vfs_model_path    (current_mod_path .. "/shapes")
mount_vfs_texture_path	(current_mod_path ..  "/textures/FG_small_Helipad.zip")
--====== FG_small_Helipad ===================================================
add_structure({
				Name 		 =  "FG_small_Helipad",
				DisplayName  = _("Y_small_Metal_Helipad"),
				ShapeName	 =   "FG_small_Helipad.edm",
				Life		 =  2500,
				Rate		 =  100,
				category     =  'Heliport',
				--SeaObject    = 	true,
				SeaObject    = 	false,
				isPutToWater =  true,
				--positioning  = 	"NO",			-- en l'air selon différentiel de relief
				--positioning  = 	"BYNORMAL",		-- pas de mise à horizontale
				positioning  = 	"ONLYHEIGTH",	    -- au sol avec mise à horizontal
				--positioning  = 	"BY_XZ",		-- ?? pas de mise à horizontale
				--positioning  = 	"ADD_HEIGTH",	-- ?? objet invisible
				classname    =  "lGasPlatform",
				numParking   =  1,
			})
plugin_done()
--====== FG_small_Helipad_Under_Construction ===================================================
declare_plugin("FG_small_Helipad_Under_Construction",{
				installed    = true, 
				state        = "installed", 
				developerName= _('Fullgas'), 
				version      = "2.7",
				description       = "Small metal helipad under construction."
				category          = "Helipad"	 -- non DCS category only for sorting mods
			  })

mount_vfs_texture_path	(current_mod_path ..  "/textures/FG_small_Helipad_Under_Construction.zip")
---------------------------------------------------------						
add_structure({
                Name         =  "FG_small_Helipad_Under_Construction",
                DisplayName  = _("Y_small_Metal_Helipad_Construction"),
                ShapeName    =   "FG_small_Helipad_Under_Construction.edm",
                Life         =  2500,
                Rate         =  100,
                category     =  'Fortification',
                positioning  =  "ONLYHEIGTH",   -- au sol avec mise à horizontal
                })
plugin_done()
